clear all
close all
clc
%% set up the enviroment
lim = [-2.0, 2.0, -2.0, 2.0, -2.0, 2.0]; % to define the limit of x,y,z
mdl_puma560     % to load the puma560 robot
p560.plot(qz,'workspace',lim)   % to draw the robot

% to define and to plot a wall 
a = 1;  % the wall is defined as ax+by+cz+d = 0 
b = 0;
c = 0;
d = -1;
wall = Wall(a,b,c,d,lim);  % to define the wall
wall.plotwall();           % to plot the wall

%% place your trajectory generation code here

% 1) An example trajectory can be loaded from the 'q.mat' file



% First letter "D" (rounded) took way too long
pD  = [0,  0, -0.35];
pD2 = [0,  0,  0.35];
pD3 = [0, -0.20,  0.30];
pD4 = [0, -0.30,  0.15];
pD5 = [0, -0.35,  0];
pD6 = [0, -0.30, -0.15];
pD7 = [0, -0.20, -0.30];
pD8 = [0,  0, -0.35];


c = [pD; pD2; pD3; pD4; pD5; pD6; pD7; pD8]

traj = mstraj (c, [1 1 1], [], [], 0.5 , 10)
%traj = mstraj(path, QDMAX, [], [], 0.5, 10);






% Lift a little, slide to the right, touch wall again
LiftPen    = [-0.05,  0, -0.35];   % lift 5 cm off wall
flyttaPen  = [-0.05,  0.20, -0.35];   % move right while lifted
BackToWall = [ 0,  0.20, -0.35];   % back on wall at A start

% First letter of my name "A"  
% Π part
pA  = [0,  0.20, -0.35];
pA2 = [0,  0.20,  0.35];
pA3 = [0,  0.40,  0.35];
pA4 = [0,  0.40, -0.35];

cA1 = [pA; pA2; pA3; pA4];

%  lift pen and draw middle bar 
LiftMid   = [-0.05, 0.40, -0.35];   % lift 5 cm off wall from pA4
MoveToBar = [-0.05, 0.20,  0];   % move to middle-bar start while lifted
BackBar   = [ 0, 0.20,  0];   % touch wall again at bar start

pA5 = [0, 0.20, 0];            % bar start draw middle line
pA6 = [0, 0.40, 0];            % bar end

cA2 = [pA5; pA6];

% combine the A:
Concat = [traj; LiftPen; flyttaPen; BackToWall; cA1; LiftMid; MoveToBar; BackBar; cA2];




trajA = mstraj(Concat, [1 1 1], [], [], 0.5, 10);


%% send to robot
Tp =SE3(0.6, 0, 0) *   SE3(trajA) * SE3.oa( [0 1 0], [1 0 0.1]);
q = p560.ikine6s(Tp);
plot_qtraj(q, wall, p560)