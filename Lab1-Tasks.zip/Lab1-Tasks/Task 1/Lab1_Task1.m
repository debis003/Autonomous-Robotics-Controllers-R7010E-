%% Task 1 (Object Cartesian Motion)
clear all
clc

%% 1) Define the four poses
A = SE3(0,0,0) * SE3.rpy(0,0,0); 
B = SE3(0,0,1) * SE3.rpy(0,pi/2,0);
C = SE3(1,0,1) * SE3.rpy(0,-pi,0);
D = SE3(1,0,-0.5) * SE3.rpy(0,pi/2,0);

%% 2) Extract waypoints from SE3 poses into matrix format
points = [
    transl(A)  tr2rpy(A);   % A: [X Y Z Roll Pitch Yaw]
    transl(B)  tr2rpy(B);   % B
    transl(C)  tr2rpy(C);   % C
    transl(D)  tr2rpy(D)    % D
];

%% 3) Generate smooth trajectory using mstraj
DT = 0.02;                      % Time step
qd = 0.4;                       % Speed (velocity limit)
TACC = 0.5;                     % Acceleration time

traj = mstraj(points, qd*ones(1,6), [], points(1,:), DT, TACC);

%% 4) Convert trajectory [x, y, z, roll, pitch, yaw] back into SE3 object for animation
n = size(traj, 1);
Ts = SE3.empty;

for i = 1:n
    xyz = traj(i, 1:3);
    rpy = traj(i, 4:6);
    Ts(i) = SE3(xyz) * SE3.rpy(rpy);
end

%% 5) Animate
Ts.animate('fps', 30);
hold on
plot3(traj(:,1), traj(:,2), traj(:,3), 'b-', 'LineWidth', 2);
grid on
xlabel('X'); ylabel('Y'); zlabel('Z');
title('Smooth Cartesian Motion: A → B → C → D');