close all
clear all
clc

% Load the fountain 3D model from file
ptCloud = pcread('fountain.ply');

% Show the fountain on screen, add labels and hold for trajectory plotting
hAx = pcshow(ptCloud);
title('Fountain with improved inspection path');
xlabel('X'); ylabel('Y'); zlabel('Z');
hold(hAx,'on'); grid(hAx,'on');

% Get all the (x,y,z) coordinates from the fountain, resahpes it to matrix format and remove invalid points (NaN values)
pts = ptCloud.Location;
pts = reshape(pts, [], 3);
pts = pts(~any(isnan(pts),2),:);   

% Find the center point of the fountain by computing the mean of x and y coordinates (average x and y positions), so like a starting point/anchor point to go around the fountain.
cx = mean(pts(:,1));
cy = mean(pts(:,2));

% Find the bottom and top of the fountain as in finding the appoximate height limits while filtering noise (ignore outliers) 
zmin = prctile(pts(:,3), 5);
zmax = prctile(pts(:,3), 95);

% Create list of heights to inspect (go up 1m at a time)
dz = 1.0;       % 1m spacing between levels (camera sees 1.5m vertically) so basically 1 meter at a time between each inspection height.
zs = zmin:dz:zmax;

% Empty list to store all inspection points
path_inspect = [];

% For each height level, create a circle of inspection points
for k = 1:length(zs) % looping through each height level then get current inspection height
    z = zs(k);  
    
    % Find all fountain points Find all points within 0.5m above or below the current height, then Extract only those points that are in this height slice
    idx = abs(pts(:,3) - z) < dz/2;
    pts_at_z = pts(idx, :);
    
    if ~isempty(pts_at_z)
        % Calculate how wide the fountain is at this height
        rxy_at_z = sqrt((pts_at_z(:,1)-cx).^2 + (pts_at_z(:,2)-cy).^2);
        R_obj_at_z = prctile(rxy_at_z, 95);  % Use 95th percentile (ignore outliers)
    else
        % If no points at this height, use overall fountain width
        rxy = sqrt((pts(:,1)-cx).^2 + (pts(:,2)-cy).^2);
        R_obj_at_z = prctile(rxy, 95);
    end
    
    % Add 1m safety distance from fountain surface
    R = R_obj_at_z + 1.0;
    
    % Calculate angle spacing to get around 1m between points around the circle
    dtheta = 1.0 / R;
    angles = 0:dtheta:(2*pi);  % All angles from 0 to 360 degrees
    
    % Create inspection points in a circle at this height
    for th = angles
        x = cx + R*cos(th);  % X position using circle formula
        y = cy + R*sin(th);  % Y position using circle formula
        path_inspect = [path_inspect; x, y, z];  % Add point to list
    end
end

% Create starting position: 3m away from fountain at middle height
start = [cx + max(sqrt((pts(:,1)-cx).^2 + (pts(:,2)-cy).^2)) + 3, ...
         cy, ...
         (zmin+zmax)/2];

% Combine starting position with all inspection points
via = [start; path_inspect];

% Create smooth trajectory through all waypoints
dt = 0.1;        % Calculate position every 0.1 seconds
vdes = 1.0;      % Fly at 1 meter per second
traj = mstraj(via, vdes*ones(1,3), [], via(1,:), dt, 0.1);

% Plot the smooth trajectory (yellow dashed line) and waypoints (red dots)
plot3(hAx, traj(:,1), traj(:,2), traj(:,3), 'y--', 'LineWidth', 1.5);
plot3(hAx, via(:,1), via(:,2), via(:,3), 'ro', 'MarkerSize', 4, 'MarkerFaceColor', 'r');
axis(hAx,'equal');

% Print useful information about the inspection path
fprintf('Fountain Inspection Statistics:\n');
fprintf('Center: (%.2f, %.2f)\n', cx, cy);
fprintf('Height range: %.2f to %.2f m\n', zmin, zmax);
fprintf('Number of height levels: %d\n', length(zs));
fprintf('Total inspection waypoints: %d\n', size(path_inspect,1));
fprintf('Total trajectory points: %d\n', size(traj,1));
fprintf('Estimated flight time: %.1f seconds\n', size(traj,1)*dt);
