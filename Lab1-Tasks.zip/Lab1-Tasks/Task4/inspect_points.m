% Inspect Points10.mat contents
clear all
close all

load('Points10.mat');

% Display what variables are loaded
fprintf('=== Variables in Points10.mat ===\n');
whos

% Check data structure
fprintf('\n=== Data Info ===\n');
fprintf('X size: %d x %d\n', size(X,1), size(X,2));
fprintf('Y size: %d x %d\n', size(Y,1), size(Y,2));
fprintf('Z size: %d x %d\n', size(Z,1), size(Z,2));

% Scale down
X = X/10;
Y = Y/10;
Z = Z/10;

% Get all points
xyz = [X Y Z];
pts = xyz;
pts = pts(~any(isnan(pts),2),:);

fprintf('\nTotal valid points: %d\n', size(pts,1));

% Find center
cx = mean(pts(:,1));
cy = mean(pts(:,2));

fprintf('Center: (%.2f, %.2f)\n', cx, cy);

% Analyze the blade region
zmin = prctile(pts(:,3), 5);
zmax = max(pts(:,3));
blade_start = zmin + 0.7 * (zmax - zmin);

fprintf('\nHeight info:\n');
fprintf('  Min Z: %.2f m\n', zmin);
fprintf('  Max Z: %.2f m\n', zmax);
fprintf('  Blade start: %.2f m\n', blade_start);

% Get blade region points
blade_pts = pts(pts(:,3) >= blade_start, :);
fprintf('\nBlade region points: %d\n', size(blade_pts,1));

% Analyze angles
angles = atan2(blade_pts(:,2) - cy, blade_pts(:,1) - cx) * 180/pi;
fprintf('\nAngle distribution:\n');
fprintf('  Min: %.1f degrees\n', min(angles));
fprintf('  Max: %.1f degrees\n', max(angles));
fprintf('  Mean: %.1f degrees\n', mean(angles));
fprintf('  Median: %.1f degrees\n', median(angles));

% Create histogram of angles
figure;
histogram(angles, 36);  % 36 bins = 10 degrees each
xlabel('Angle (degrees)');
ylabel('Number of points');
title('Distribution of Blade Points by Angle');
grid on;
