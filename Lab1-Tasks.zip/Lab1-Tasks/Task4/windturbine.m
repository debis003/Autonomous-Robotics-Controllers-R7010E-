close all
clear all
clc

% Load and scale the turbine point cloud
load('Points10.mat');
X = X/10;
Y = Y/10;
Z = Z/10;
xyz = [X Y Z];

% Plot the turbine
figure;
plot3(X, Y, Z, '.');
hold on;
grid on;
box on;
axis equal;
ylim([-20 20]);
title('Wind Turbine - Inspection Path');
xlabel('X'); ylabel('Y'); zlabel('Z');

% Remove invalid points
pts = xyz;
pts = pts(~any(isnan(pts),2),:);

% Find turbine center and height bounds
cx = mean(pts(:,1));
cy = mean(pts(:,2));
zmin = prctile(pts(:,3), 5);
zmax = max(pts(:,3));

%% Set up reference frames for hub and blades
hub_height = 41;
TH = SE3(cx, cy, hub_height);  % Hub center frame
TLB = SE3(-25, cy, 27) * SE3.Ry(deg2rad(60));  % Left blade frame

%% Starting point
start_point = [10, 10, 5];

%% Tower path - helix going up the tower
path_tower = create_helix(7, 1, 36, 14, 20);

%% Hub path - horizontal helix around the back of the hub
hub_center_xz = [cx, 41];
hub_y_offset = 4;
path_hub_back = create_helix_horizontal(7, -8, 2, 3, 20);
path_hub_back(:,1) = path_hub_back(:,1) + hub_center_xz(1);
path_hub_back(:,2) = path_hub_back(:,2) + hub_y_offset;
path_hub_back(:,3) = path_hub_back(:,3) + hub_center_xz(2);

%% Top blade path
path_top_blade = create_helix(5, 5, 30, 10, 20);
path_top_blade_transformed = TH * SE3(path_top_blade);
path_top_blade = path_top_blade_transformed.transl;
path_top_blade(:,2) = path_top_blade(:,2) - 2;  % Shift to avoid collision
path_top_blade = path_top_blade(3:end,:);

%% Right blade path
path_right_blade = create_helix(5, 5, 30, 10, 20);
path_right_blade_transformed = TH * SE3.Ry(deg2rad(120)) * SE3(path_right_blade);
path_right_blade = path_right_blade_transformed.transl;
path_right_blade(:,1) = path_right_blade(:,1) - 2;  % Shift to avoid collision
path_right_blade(:,2) = path_right_blade(:,2) - 2;
path_right_blade = path_right_blade(3:end,:);

%% Left blade path
path_left_blade = create_helix(5, 5, 28, 9, 20);
path_left_blade_transformed = TLB * SE3(path_left_blade);
path_left_blade = path_left_blade_transformed.transl;
path_left_blade(:,1) = path_left_blade(:,1) - 2;  % Shift to avoid collision
path_left_blade(:,2) = path_left_blade(:,2) - 2;
path_left_blade = path_left_blade(3:end,:);

%% Return to start
return_point = start_point;

%% Put all paths together
all_paths = [start_point; path_tower; path_hub_back; path_right_blade; path_top_blade; path_left_blade; return_point];

%% Make smooth trajectory with mstraj
t = all_paths';
traj = mstraj(t(:,2:end)', [5,5,5], [], t(:,1)', 0.2, 0.5);

%% Plot everything
plot3(start_point(1), start_point(2), start_point(3), 'g*', 'MarkerSize', 20, 'LineWidth', 2);
plot3(all_paths(:,1), all_paths(:,2), all_paths(:,3), 'b.', 'MarkerSize', 10);
plot3(traj(:,1), traj(:,2), traj(:,3), 'r-', 'LineWidth', 2);
legend('Start Point', 'Waypoints', 'Trajectory', 'Location', 'best');

%% Helper functions
function coords = create_helix(diameter, min_height, max_height, nloops, points_per_loop)
    % Vertical helix that spirals upward
    theta = [];
    for i = 1:nloops
        theta = [theta linspace(0, 2*pi, points_per_loop)];
    end
    height = linspace(min_height, max_height, points_per_loop*nloops);

    coords = [];
    coords(:,1) = diameter/2 * cos(theta);
    coords(:,2) = diameter/2 * sin(theta);
    coords(:,3) = height;
end

function coords = create_helix_horizontal(diameter, min_y, max_y, nloops, points_per_loop)
    % Horizontal helix that extends along Y axis
    theta = [];
    for i = 1:nloops
        theta = [theta linspace(0, 2*pi, points_per_loop)];
    end
    y_pos = linspace(min_y, max_y, points_per_loop*nloops);

    coords = [];
    coords(:,1) = diameter/2 * cos(theta);
    coords(:,2) = y_pos;
    coords(:,3) = diameter/2 * sin(theta);
end

%I defined where things are (SE3 frames)
%I created spiral patterns around those locations (helixes)
%I transformed those patterns to the right positions (SE3 transformations)
%I avoided collisions by shifting paths
%I smoothed everything into a flyable trajectory (mstraj)


