%clear
clear all
clc
close all
addpath(genpath('./'));
p_init = [-5,2,0]; %Initial position
goal = [22,2,0]; %Goal position
%% Create trajectory path for Map 1 (task 4.1)
path = [ p_init;...
         -5,2,5;...      % Climb to z=5 (above blue blocks)
         2,2,5;...       
         2,2,1;...       % Drop to z=1 (below red blocks) - through first gap
         5,2,1;...       
         5,2,5;...       Climb to z=5  
         8,2,5;...      
         8,2,1;...       % Drop to z=1 - through third gap
         11,2,1;...      
         11,2,5;...       Climb to z=5
         14,2,5;...     
         14,2,1;...      % Drop to z=1 - through fifth gap
         17,2,1;...      
         17,2,5;...      & Climb to z=5
         22,2,5;...      
         goal];          % Descend to goal at z=0
%%     
QDMAX = [1,1,1]; %Axis speed limits
Q0 = path(1,:); %Initial axis coordinates
DT = 0.2;
traj = mstraj(path, QDMAX, [], Q0, DT, 3);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Map 2 start and goal
p_init = [5, 1, 0];   % Start position
goal = [5, 20, 2];    % Goal position

% Create trajectory path for Map 2 ( task 4.2)
path = [ p_init;...
         5, 1, 3;...      % Climb to z=3 in the gap 
         5, 14, 3;...     % Approach top section
         5, 14, 4;...     % Climb in the gap to z=4
         5, 20, 4;...     % Exit gap
         goal];           % Descend to goal at z=2

QDMAX = [1,1,1]; % Axis speed limits
Q0 = path(1,:);       % Initial axis coordinates
DT = 0.2;
traj = mstraj(path, QDMAX, [], Q0, DT, 3);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


%Load and plot the map
% map1.txt and map1.txt are the complex enviroments
map = load_map('maps/map2.txt', 0.1, 2, 0.25);
plot_path(map);  % plot_path only accepts one argument
grid on
box on


% Plot the trajectory path 
hold on;
plot3(traj(:,1), traj(:,2), traj(:,3), 'k--', 'LineWidth', 1.5);
plot3(path(:,1), path(:,2), path(:,3), 'ro', 'MarkerSize', 8, 'MarkerFaceColor', 'r'); % Show paths points
axis equal;
xlabel('x'); ylabel('y'); zlabel('z');
%title('MAV animation in Map 1');
title('MAV animation in Map 2');

L = 0.7;              % heading arrow length
N = size(traj,1);     % Use traj size, not waypoints
skip = 2;             % use every 2nd point to speed up animation

%%   Animate along the path (re-draw each frame) 
for k = 2:skip:N
    p = traj(k,:);    % Use traj, not waypoints

    % compute heading from previous point
    v = traj(k,:) - traj(max(k-1,1),:);  % Use traj, not waypoints
    if norm(v) > 1e-6
        dir = v / norm(v);
    else
        dir = [1 0 0];
    end
    head = p + L*dir;

    % clear previous MAV marker & heading only
    if k > 2
        delete(hmav);
        delete(hhead);
    end

    % draw MAV marker
    hmav = plot3(p(1), p(2), p(3), 'bo', ...
                 'MarkerSize', 8, 'MarkerFaceColor', 'b');

    % draw heading arrow
    hhead = plot3([p(1) head(1)], ...
                  [p(2) head(2)], ...
                  [p(3) head(3)], 'b-', 'LineWidth', 2);

    drawnow;
    pause(0.02);
end